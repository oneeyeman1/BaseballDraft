#pragma once
class CMainFrane :	public wxFrame
{
public:
	CMainFrane(void);
	~CMainFrane(void);
};

