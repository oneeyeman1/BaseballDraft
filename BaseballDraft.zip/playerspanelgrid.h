#pragma once
class CPlayersPanelGrid :	public wxGrid
{
public:
	CPlayersPanelGrid(void);
	~CPlayersPanelGrid(void);
};

